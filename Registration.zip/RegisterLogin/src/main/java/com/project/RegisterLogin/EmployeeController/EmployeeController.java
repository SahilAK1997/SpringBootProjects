package com.project.RegisterLogin.EmployeeController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.RegisterLogin.Dto.EmployeeDto;
import com.project.RegisterLogin.Dto.LoginDto;
import com.project.RegisterLogin.Service.EmployeeService;
import com.project.RegisterLogin.responce.LoginResponce;

@RestController
@CrossOrigin
@RequestMapping("api/v1/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeservice;
	
	@PostMapping("/save")
	public  String saveEmployee(@RequestBody EmployeeDto employeedto) {
		System.out.println("hello save controller");
		String id = employeeservice.addEmployee(employeedto);
		return id;
	}
	@PostMapping("/login")
	public  ResponseEntity<?> loginEmployee(@RequestBody LoginDto logindto) {
		
		LoginResponce loginresponce = employeeservice.loginEmployee(logindto);
		return ResponseEntity.ok(loginresponce);
	}

}
