package com.project.RegisterLogin.Service;

import com.project.RegisterLogin.Dto.EmployeeDto;
import com.project.RegisterLogin.Dto.LoginDto;
import com.project.RegisterLogin.responce.LoginResponce;

public interface EmployeeService {

	
	String addEmployee(EmployeeDto employeedto);

	LoginResponce loginEmployee(LoginDto logindto);

}
