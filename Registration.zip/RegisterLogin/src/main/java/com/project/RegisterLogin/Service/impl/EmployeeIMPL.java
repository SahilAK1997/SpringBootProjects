package com.project.RegisterLogin.Service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.project.RegisterLogin.Dto.EmployeeDto;
import com.project.RegisterLogin.Dto.LoginDto;
import com.project.RegisterLogin.Entity.Employee;
import com.project.RegisterLogin.Repo.EmployeeRepo;
import com.project.RegisterLogin.Service.EmployeeService;
import com.project.RegisterLogin.responce.LoginResponce;

@Service
public class EmployeeIMPL implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private  PasswordEncoder passwordEncoder;
	
	@Override
	public String addEmployee(EmployeeDto employeedto) {
		
		Employee employee = new Employee(
				employeedto.getEmployeeid(),
				employeedto.getEmployeename(),
				employeedto.getEmail(),
				this.passwordEncoder.encode(employeedto.getPassword())
				
				);
		employeeRepo.save(employee);
		return employee.getEmployeename();
	}

	@Override
	public LoginResponce loginEmployee(LoginDto logindto) {
		
		String msg="";
		Employee employee1=employeeRepo.findByEmail(logindto.getEmail());
		
				if(employee1 !=null)
				{
					String password = logindto.getPassword();
					String encodedPassword=employee1.getPassword();
					Boolean isPwdRight= passwordEncoder.matches(password, encodedPassword);
					
					if(isPwdRight)
					{
						Optional<Employee> employee = employeeRepo.findOneByEmailAndPassword(logindto.getEmail(), encodedPassword);
					
					  if(employee.isPresent())
					  {
						  return new LoginResponce("Login Successfull ", true);
					  }else
					  {
						  return new LoginResponce("Login Failed ", false);
					  }
					
					}else
					{
						 return new LoginResponce("Password Not match ", false);
					}
					
					
				}else
				{
					 return new LoginResponce(" Email not exits ", false);
				}
				
				
		
	}

}






























