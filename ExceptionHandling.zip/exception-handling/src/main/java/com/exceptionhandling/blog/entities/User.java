package com.exceptionhandling.blog.entities;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="users")
@NoArgsConstructor    //to create user object (its a lombok function)
@Getter
@Setter
public class User {
	
	
	
	@Id
	@Column(name="id",length=45,unique=true)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="user_name",nullable = false,length=100)
	private String name;
	
	@Column(name="email",length=200 , unique=true)
	private String email;
	private String password;
	private String about;
	

}
