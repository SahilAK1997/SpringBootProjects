package com.exceptionhandling.blog.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exceptionhandling.blog.entities.User;

public interface UserRepo extends JpaRepository<User, Integer>{

	boolean existsByEmail(String email);
}
