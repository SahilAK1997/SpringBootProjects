package com.exceptionhandling.blog.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import com.exceptionhandling.blog.exceptions.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exceptionhandling.blog.entities.User;
import com.exceptionhandling.blog.payloads.UserDto;
import com.exceptionhandling.blog.repositories.UserRepo;
import com.exceptionhandling.blog.services.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userrepo;
	
	
	@Override
	public UserDto createUser(UserDto userdto) {
		
		String email=userdto.getEmail();
		 if (userrepo.existsByEmail(email)) {
	            throw new DuplicateEntry(email);
	        }
		 
		
		User user=this.dtoToUser(userdto);
		
	User savedUser = this.userrepo.save(user);  //ctrl+2 l
		
		return this.userToDto(savedUser);
	}

	@Override
	public UserDto updateUser(UserDto userDto, Integer userId) {
		
		String email=userDto.getEmail();
		 if (userrepo.existsByEmail(email)) {
	            throw new DuplicateEntry(email);
	        }
		
		User user =this.userrepo.findById(userId)
				.orElseThrow(()-> new ResourceNotFoundException("User","id",userId));
		
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail()); 
		user.setAbout(userDto.getAbout());
		user.setPassword(userDto.getPassword());
		
		User updatedUser = this.userrepo.save(user);
		UserDto userDto1 = this.userToDto(updatedUser);
		
		return userDto1;
	}

	@Override
	public UserDto getUserById(Integer userId) {
		
		User user =this.userrepo.findById(userId)
				.orElseThrow(()-> new ResourceNotFoundException("User","id",userId));
		
		return this.userToDto(user);
	}

	@Override
	public List<UserDto> getAllUsers() {
		
		List<User> users = this.userrepo.findAll();
		
		List<UserDto> userDtos = users.stream().map(user->this.userToDto(user)).collect(Collectors.toList());
		
		return userDtos;
	}

	@Override
	public void deteleUser(Integer userId) {
		
		User user=this.userrepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User", "Id", userId));
        this.userrepo.delete(user);
	}
	
	
	private User dtoToUser(UserDto userDto)
	{
		User user =new User();
		user.setId(userDto.getId());
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail()); 
		user.setAbout(userDto.getAbout());
		user.setPassword(userDto.getPassword());
		
		return user;
	}
	
	private UserDto userToDto(User user)
	{
		UserDto userdto =new UserDto();
		
		userdto.setId(user.getId());
		userdto.setName(user.getName());
		userdto.setEmail(user.getEmail()); 
		userdto.setAbout(user.getAbout());
		userdto.setPassword(user.getPassword());
		
		return userdto;
	}
	

}
