package com.exceptionhandling.blog;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.exceptionhandling.blog.repositories.UserRepo;

@SpringBootTest
class ExceptionHandlingApplicationTests {

	@Autowired
     private UserRepo userrepo;
	



	@Test
	void contextLoads() {
	}

	@Test
	public void repoTest()
	{
		String classname = this.userrepo.getClass().getName();
		String packageName = this.userrepo.getClass().getPackageName();
	System.out.println(classname);
	System.out.println(packageName);
	
	}
}
